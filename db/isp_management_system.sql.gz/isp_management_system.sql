-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2017 at 09:24 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `isp_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `A_ID` int(11) NOT NULL,
  `A_Name` varchar(25) DEFAULT NULL,
  `A_Phn` varchar(15) DEFAULT NULL,
  `A_Email` varchar(255) DEFAULT NULL,
  `A_Address` varchar(50) DEFAULT NULL,
  `A_Password` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`A_ID`, `A_Name`, `A_Phn`, `A_Email`, `A_Address`, `A_Password`) VALUES
(16303009, 'Tajrian Tabassum', '01721105564', 'taba@gmail.com', 'Gazipur,Dhaka', '12345'),
(16303021, 'Farjana Easmin Mim', '01701864933', 'mim420@gmail.com', 'Kawla,Dhaka', '12345'),
(16303023, 'Zubayer Bin Muntasir', '01717670944', 'zubayer.hamim@gmail.com', 'Sector#10,Uttara', '12345'),
(16303025, 'S M Abdullah', '01754170067', 's.m.abdullah.kst@gmail.com', 'Sector#10, Uttara', '12345'),
(16303030, 'Md.Masum Billah', '01763256182', 'm.billahkst@gmail.com', 'Sector#10,Uttara', '12345'),
(16303051, 'Moumita Das', '01833219221', 'mou.das@gmail.com', 'Gazipur,Dhaka', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `B_Trnx` int(11) NOT NULL,
  `Amount` int(5) DEFAULT NULL,
  `C_ID` int(11) NOT NULL,
  `B_Date` varchar(10) NOT NULL,
  `P_Name` varchar(20) DEFAULT NULL,
  `Payment_Process` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`B_Trnx`, `Amount`, `C_ID`, `B_Date`, `P_Name`, `Payment_Process`) VALUES
(3, 500, 4, '21th Nov,2', 'Silver', 'B_Kash'),
(4, 1500, 66, '18', 'Titenium', 'Cash');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `C_ID` int(11) NOT NULL,
  `C_Name` varchar(50) DEFAULT NULL,
  `C_Phn` varchar(15) DEFAULT NULL,
  `C_Email` varchar(50) DEFAULT NULL,
  `C_Address` varchar(100) DEFAULT NULL,
  `P_Name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`C_ID`, `C_Name`, `C_Phn`, `C_Email`, `C_Address`, `P_Name`) VALUES
(4, 'Ashikur Rahaman Priya', '01705276833', 'ashik420@gmail.com', 'Sector#10,Uttara', 'Silver'),
(5, 'Al-Mahbub Alam Tushar', '01763256182', 'faijusanam@gmail.com', 'House#31,West Rajabazar,Farmgate', 'Titenium'),
(6, 'Kowshiq Asfat', '01688945899', 'kowshiq.asfat@gmail.com', '0', 'Golden'),
(7, 'Zubayer Hamim', '01767564511', 'hamim_991@yahoo.com', 'Uttara', 'Golden'),
(9, '', '', '', 'KEWEOFJ9', 'Silver'),
(12, 'Moon', '01754556325', 'moon@yahoo.com', 'Uttara', 'Titenium'),
(13, 'Zubayer Hamim', '01878964588', 'hamim_991@yahoo.com', 'UTTARA', 'Golden');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `E_ID` int(11) NOT NULL,
  `E_Name` varchar(50) DEFAULT NULL,
  `E_Email` varchar(50) DEFAULT NULL,
  `E_Phn` varchar(15) DEFAULT NULL,
  `E_Address` varchar(100) DEFAULT NULL,
  `Designation` varchar(50) DEFAULT NULL,
  `D_Joining` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`E_ID`, `E_Name`, `E_Email`, `E_Phn`, `E_Address`, `Designation`, `D_Joining`) VALUES
(1, 'Md.Farhad', 'farhad@hotmail.com', '01924886032', 'Bannar Tek, Turag,Dhaka', 'Technician', '19th Nov,2017'),
(3, 'Md. Alamgir Bhuyan', 'a.bhuyan@error.net', '01694325871', 'House#53, Road#12, Sector#10, Uttara', 'Engineer', '19th Nov,2017'),
(4, 'moumi', 'moumi@gmail.com', '01878631221', 'Bannar Tek, Turag,Dhaka', 'Accountant', '5-11-2001'),
(5, 'Tajrian Taba', 'taba@gmail.com', '0178545896', 'Tongi', 'Technician', '13th Feb, 1997');

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `P_ID` int(10) NOT NULL,
  `P_Name` varchar(50) DEFAULT NULL,
  `Cost` varchar(50) DEFAULT NULL,
  `Speed` varchar(50) DEFAULT NULL,
  `P_Date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`P_ID`, `P_Name`, `Cost`, `Speed`, `P_Date`) VALUES
(1, 'Silver', '500', '1 mbps', '21th,November'),
(2, 'Gold', '700', '1.5 mbps', '21th,November'),
(3, 'Dimond', '1000', '2 mbps', '20th,November');

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `S_Trnx` int(11) NOT NULL,
  `S_Amount` int(12) DEFAULT NULL,
  `S_Date` varchar(10) DEFAULT NULL,
  `E_ID` int(10) DEFAULT NULL,
  `Bank_Ac` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`S_Trnx`, `S_Amount`, `S_Date`, `E_ID`, `Bank_Ac`) VALUES
(1, 10000, '20th Nov,2', 1, 'a/c-1001');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`A_ID`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`B_Trnx`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`C_ID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`E_ID`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`P_ID`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`S_Trnx`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `B_Trnx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `C_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `E_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `P_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `S_Trnx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
